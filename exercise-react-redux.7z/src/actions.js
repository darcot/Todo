/***********
 * Redux actions file.
 *
 * All your actions should be declared here.
 ***********/

import * as types from 'actionTypes';
import * as api from 'api';

/**
 * This is an action to mock a login API call, for your reference.
 */
export function login() {
    return dispatch => {
        return api.login()
            .then(user => {
                return dispatch({ type: types.APP_LOGIN, payload: { user } })
            });
    }
}

export function getCompletedTasks() {
    return dispatch => {
        return api.getTasks(true)
            .then(tasks => {
                return dispatch({ type: types.GET_COMPLETED_TASKS, payload: { tasks } })
            });
    }
}

export function getToDoTasks() {
    return dispatch => {
        return api.getTasks(false)
            .then(tasks => {
                return dispatch({ type: types.GET_TODO_TASKS, payload: { tasks } })
            });
    }
}

