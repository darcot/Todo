/******
 * Redux action constants.
 *
 * You can add any action constants you need here.
 ******/

export const APP_LOGIN = 'app/LOGIN';
export const GET_COMPLETED_TASKS = 'app/COMPLETED-TASKS';
export const GET_TODO_TASKS = 'app/TODO-TASKS';
